// 1. Import environment variables and dependencies
const {
    RDS_REGION,
    PROXY_ENDPOINT,
    DB_NAME,
    DB_USERNAME
} = process.env;

const { Signer } = require("@aws-sdk/rds-signer");
const mysql = require('mysql2/promise');
let connection;

async function getConnection() {
    if (connection && connection.threadId) {
        return connection;
    }

    const signer = new Signer({
        region: RDS_REGION,
        hostname: PROXY_ENDPOINT,
        port: 3306,
        username: DB_USERNAME
    });

    let token = await signer.getAuthToken({ username: DB_USERNAME });

    let connectionConfig = {
        host: PROXY_ENDPOINT,
        user: DB_USERNAME,
        database: DB_NAME,
        password: token,
        ssl: { rejectUnauthorized: false },
        authPlugins: { mysql_clear_password: () => () => signer.getAuthToken() }
    };

    connection = await mysql.createConnection(connectionConfig);
    console.log(connection.threadId);
    return connection;
}

exports.handler = async (event, context) => {
    console.log(event);
    const { info, arguments: args } = event;
    const conn = await getConnection();

    try {
        switch (info.fieldName) {
            case 'getAuthor':
                const author = await getAuthorById(conn, args.id);
                return { error: null, data: author };

            case 'listAuthors':
                const authorsList = await listAuthors(conn, args);
                return { error: null, data: authorsList };

            case 'createAuthor':
                const newAuthor = await createAuthor(conn, args.input);
                return { error: null, data: newAuthor };

            case 'updateAuthor':
                const updatedAuthor = await updateAuthor(conn, args.input);
                return { error: null, data: updatedAuthor };

            case 'deleteAuthor':
                const deletedAuthor = await deleteAuthor(conn, args.input);
                return { error: null, data: deletedAuthor };

            default:
                throw new Error('Invalid field');
        }
    }
    catch (error) {
        console.error(error);
        // if (connection) connection.end();
        return { error: { message: error.message ?? error.errorMessage, name: error.name ?? error.Type }, data: null };
    }
};

async function getAuthorById(conn, id) {
    const [rows] = await conn.execute('SELECT * FROM authors WHERE id = ?', [id]);
    if (rows.length === 0) {
        throw new Error('Author not found');
    }
    return rows[0];
}

async function listAuthors(conn, args) {
    const pageSize = args.pageSize ?? 50;
    const pageNumber = ((args.pageNumber ?? 1) - 1) * pageSize;
    const [rows] = await conn.execute('SELECT * FROM authors LIMIT ? OFFSET ?', [pageSize.toString(), pageNumber.toString()]);
    return rows;
}

async function createAuthor(conn, input) {
    console.log("Input Object:", JSON.stringify(input));

    // Convert undefined to null for all properties
    const { id, name, numBooks, hometown, country } = input;
    const sanitizedInput = {
        id: id || null,
        name: name || null,
        numBooks: numBooks || null,
        hometown: hometown || null,
        country: country || null
    };

    const [result] = await conn.execute(
        'INSERT INTO authors (id, name, numBooks, hometown, country) VALUES (?, ?, ?, ?, ?)',
        [sanitizedInput.id, sanitizedInput.name, sanitizedInput.numBooks, sanitizedInput.hometown, sanitizedInput.country]
    );

    console.log("Result:", result);

    return {
        id: result.insertId,
        ...sanitizedInput,
    };
}

async function updateAuthor(conn, input) {
    console.log("Update Input:", JSON.stringify(input));
    const { id } = input;

    let updateObj = {};
    for (let key in input) {
        if (input[key] !== undefined) {
            updateObj[key] = input[key];
        }
    }

    delete updateObj.id;
    if (Object.keys(updateObj).length === 0) {
        throw new Error('No fields to update');
    }

    const updateData = [];
    for (const [key, value] of Object.entries(updateObj)) {
        updateData.push(`${key} = ?`);
    }

    const updateString = updateData.join(', ');
    await conn.execute(`UPDATE authors SET ${updateString} WHERE id = ?`, [...Object.values(updateObj), id]);
    const [rows] = await conn.execute('SELECT * FROM authors WHERE id = ?', [id]);
    if (rows.length === 0) {
        throw new Error('Author not found');
    }
    return { id, ...rows[0] };
}

async function deleteAuthor(conn, input) {
    const { id } = input;
    const [rows] = await conn.execute('SELECT * FROM authors WHERE id = ?', [id]);
    if (rows.length === 0) {
        throw new Error('Author not found');
    }
    await conn.execute('DELETE FROM authors WHERE id = ?', [id]);
    return { id, ...rows[0] };
}