/*
MIT No Attribution

Copyright 2023 Amazon.com, Inc. or its affiliates. All Rights Reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy of this
software and associated documentation files (the "Software"), to deal in the Software
without restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

const {
    CognitoIdentityProviderClient,
    AdminGetUserCommand,
    ListUsersCommand
} = require("@aws-sdk/client-cognito-identity-provider");

const cognitoClient = new CognitoIdentityProviderClient();

exports.handler = async function (event, context) {

    console.log("event " + JSON.stringify(event));

    switch (event.resource) {
        case '/users':
            const listResponse = await listUsers(parseInt(event.queryStringParameters.limit), decodeURI(event.queryStringParameters.nextToken));
            return listResponse;
        case '/users/{username}':
            const getUserResponse = await getUser(event.queryStringParameters.username);
            return getUserResponse;
    }

    return {
        statusCode: 400,
        body: JSON.stringify({
            "errors": "Invalid API path"
        })
    };
};

async function getUser(username) {
    const input = {
        UserPoolId: process.env.UserPoolId,
        Username: username
    };

    try {
        const response = await cognitoClient.send(new AdminGetUserCommand(input));

        var attributes = {}
        response.UserAttributes.forEach((attr) => {
            attributes[attr.Name] = attr.Value;
        });

        return setResult({
            status: 200,
            body: {
                id: attributes.sub,
                username: username,
                email: attributes.email
            }
        }, true);
    } catch (e) {
        if (e.name === 'UserNotFoundException') {
            return setResult({
                status: 404,
                body: {
                    "error": "User not found"
                }
            }, true);
        }
    }
}

async function listUsers(limit, nextToken) {
    const input = {
        UserPoolId: process.env.UserPoolId,
        AttributesToGet: [
            "sub", "email"
        ],
        Limit: limit,
        PaginationToken: (nextToken !== '') ? nextToken : null
    };

    try {
        const response = await cognitoClient.send(new ListUsersCommand(input));
        const users = response.Users.map((user) => {

            var attributes = {};
            user.Attributes.forEach((attr) => {
                attributes[attr.Name] = attr.Value;
            });

            return {
                id: attributes.sub,
                email: attributes.email,
                username: user.Username
            };
        });

        return setResult({
            status: 200,
            body: {
                items: users,
                nextToken: response.PaginationToken
            },
        }, true);
    } catch (e) {
        console.log(e);
        return setResult({
            status: 500,
            body: {
                "error": "Something went wrong"
            }
        }, true);
    }
}

function setResult(result, stringify) {
    var response = {};
    response.statusCode = result.status;
    if (stringify) {
        response.body = JSON.stringify(result.body);
    } else {
        response.body = result.body;
    }
    return response;
}