// 1. Import environment variables and dependencies
const { REVIEWS_TABLE_NAME, REGION } = process.env;
const { uuid } = require('uuidv4');
const {
    DynamoDBDocumentClient,
    QueryCommand,
    UpdateCommand,
    GetCommand,
    DeleteCommand,
    PutCommand
} = require("@aws-sdk/lib-dynamodb");
const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");

// 2. Instantiate dynamodb document client
const client = DynamoDBDocumentClient.from(new DynamoDBClient({ region: REGION }));

// 3. Define the handler function
exports.handler = async function (event) {
    console.log("event " + JSON.stringify(event));
    const { info: { fieldName }, ...rest } = event;
    try {
        switch (fieldName) {
            case 'getReview':
                return await getItem(rest);

            case 'listReviewsByBookId':
                return await listReviewsByBookId(rest);

            case 'createReview':
                return await createReview(rest);

            case 'updateReview':
                return await updateReview(rest);

            case 'deleteReview':
                return await deleteReview(rest);

            default:
                throw new Error(`Unknown fieldName: ${fieldName}`);
        }
    }
    catch (error) {
        console.error(error);
        return { error: { message: error.message ?? error.errorMessage, name: error.name ?? error.Type }, data: null };
    }
}

// 4. Define the helper functions
async function getItem(rest) {
    const { arguments: { id } } = rest;
    const params = {
        TableName: REVIEWS_TABLE_NAME,
        Key: { id }
    };
    const data = await client.send(new GetCommand(params));
    console.log(data);
    return { error: null, data: data.Item };
}

async function listReviewsByBookId(rest) {
    const { arguments: { bookId, limit = 50, nextToken = null } } = rest
    const params = {
        TableName: REVIEWS_TABLE_NAME,
        KeyConditionExpression: 'bookId = :bookId',
        ExpressionAttributeValues: { ':bookId': bookId },
        ScanIndexForward: false,
        Limit: limit,
        IndexName: 'bookId-index'
    };
    if (nextToken) {
        params.ExclusiveStartKey = nextToken;
    }
    const data = await client.send(new QueryCommand(params));
    console.log(data);
    return { error: null, data: { items: data.Items, nextToken: data.LastEvaluatedKey } };
}

async function deleteReview(rest) {
    const { arguments: { input: { id } } } = rest;
    const params = {
        TableName: REVIEWS_TABLE_NAME,
        Key: { id },
        ReturnValues: 'ALL_OLD'
    };
    const data = await client.send(new DeleteCommand(params));
    console.log(data);
    return { error: null, data: data.Attributes };
}

async function createReview(rest) {
    const { arguments: { input: { bookId, userId, rating, comment } } } = rest;
    const id = uuid();
    const createdAt = new Date().toISOString();
    const params = {
        TableName: REVIEWS_TABLE_NAME,
        Item: { id, bookId, userId, rating, createdAt, comment },
    };
    const data = await client.send(new PutCommand(params));
    console.log(data);
    return { error: null, data: params.Item };
}

async function updateReview(rest) {
    const { arguments: { input: { id, ...values } } } = rest;

    const sets = [];
    const removes = [];
    const expressionNames = {};
    const expValues = {};

    for (const key in values) {
        expressionNames[`#${key}`] = key;
        const value = values[key];
        if (value) {
            sets.push(`#${key} = :${key}`);
            expValues[`:${key}`] = value;
        }
        else {
            removes.push(`#${key}`);
        }
    }

    let expression = '';
    expression += sets.length ? `SET ${sets.join(', ')}` : '';
    expression += removes.length ? ` REMOVE ${removes.join(', ')}` : '';

    const params = {
        TableName: REVIEWS_TABLE_NAME,
        Key: { id },
        UpdateExpression: expression,
        ExpressionAttributeValues: expValues,
        ExpressionAttributeNames: expressionNames,
        ReturnValues: 'ALL_NEW'
    };
    const data = await client.send(new UpdateCommand(params));
    console.log(data);
    return { error: null, data: data.Attributes };
}