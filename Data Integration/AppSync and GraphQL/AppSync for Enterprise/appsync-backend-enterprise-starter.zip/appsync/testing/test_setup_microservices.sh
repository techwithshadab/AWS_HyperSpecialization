#!/bin/bash

cd ~/environment/AnyCompanyReads-backend
export API_URL=`jq -r .AnyCompanyReadsMicroservicesApiStack.MicroservicesGraphQLAPIURL ./enterprise-output.json`
CLIENT_ID=`jq -r .AnyCompanyReadsBackendStack.USERPOOLSWEBCLIENTID ./output.json`
USER_POOL_ID=`jq -r .AnyCompanyReadsBackendStack.USERPOOLSID ./output.json`
EMAIL_EXT="@example.com"

if [ $1 == "login" ]; then
    echo "==== Amazon Cognito Login ===="
    echo -n "Enter password for admin user: "  
    read -s password
    echo
    
    export AUTH_TOKEN=$(sed -e 's/^"//' -e 's/"$//' <<< $(aws cognito-idp initiate-auth \
      --client-id $CLIENT_ID \
      --auth-flow USER_PASSWORD_AUTH \
      --auth-parameters USERNAME=admin,PASSWORD=$password \
      | jq '.AuthenticationResult.AccessToken'))
else
    echo "==== Invalid command line argument ===="
fi