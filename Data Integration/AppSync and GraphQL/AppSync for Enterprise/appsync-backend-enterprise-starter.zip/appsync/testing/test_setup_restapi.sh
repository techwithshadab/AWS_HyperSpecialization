#!/bin/bash

cd ~/environment/AnyCompanyReads-backend
export API_URL=`jq -r .AnyCompanyReadsRESTApiStack.UsersGraphQLAPIURL ./enterprise-output.json`
CLIENT_ID=`jq -r .AnyCompanyReadsBackendStack.USERPOOLSWEBCLIENTID ./output.json`
USER_POOL_ID=`jq -r .AnyCompanyReadsBackendStack.USERPOOLSID ./output.json`
EMAIL_EXT="@example.com"

if [ $1 == "create" ]; then
    echo "==== Generating 10 test users ===="
    
    for i in {1..10}
    do
        EMAIL="email${i}${EMAIL_EXT}"
        USERNAME="user${i}"
        RESPONSE=$(aws cognito-idp admin-create-user --user-pool-id $USER_POOL_ID \
            --username $USERNAME \
            --user-attributes Name=email,Value=$EMAIL Name=email_verified,Value=true \
            --query "User.Username"
        )
        echo "Created: "$RESPONSE
    done
    
    echo "==== Amazon Cognito Login ===="
    echo -n "Enter password for admin user: "  
    read -s password
    echo
    
    export AUTH_TOKEN=$(sed -e 's/^"//' -e 's/"$//' <<< $(aws cognito-idp initiate-auth \
      --client-id $CLIENT_ID \
      --auth-flow USER_PASSWORD_AUTH \
      --auth-parameters USERNAME=admin,PASSWORD=$password \
      | jq '.AuthenticationResult.AccessToken'))
elif [ $1 == "delete" ]; then
    echo "==== Deleteing 10 test users ===="
    
    for i in {1..10}
    do
        EMAIL="email${i}${EMAIL_EXT}"
        USERNAME="user${i}"
        RESPONSE=$(aws cognito-idp admin-delete-user --user-pool-id $USER_POOL_ID \
            --username $USERNAME
        )
        echo "Deleted: "$USERNAME
    done
else
    echo "==== Invalid command line argument ===="
fi