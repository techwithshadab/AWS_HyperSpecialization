/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const onCreateBook = /* GraphQL */ `
  subscription OnCreateBook {
    onCreateBook {
      id
      title
      authorId
      publisherId
      genres
      publicationYear
      image
      description
      __typename
    }
  }
`;
export const onUpdateBook = /* GraphQL */ `
  subscription OnUpdateBook {
    onUpdateBook {
      id
      title
      authorId
      publisherId
      genres
      publicationYear
      image
      description
      __typename
    }
  }
`;
export const onDeleteBook = /* GraphQL */ `
  subscription OnDeleteBook {
    onDeleteBook {
      id
      title
      authorId
      publisherId
      genres
      publicationYear
      image
      description
      __typename
    }
  }
`;
export const onCreateReview = /* GraphQL */ `
  subscription OnCreateReview {
    onCreateReview {
      id
      bookId
      userId
      rating
      comment
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const onCreateReviewFiltered = /* GraphQL */ `
  subscription OnCreateReview($bookId: ID!) {
    onCreateReview(bookId: $bookId) {
      id
      bookId
      userId
      rating
      comment
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const subscribeBookRecommendation = /* GraphQL */ `
  subscription SubscribeBookRecommendation($toUser: String!) {
    subscribeBookRecommendation(toUser: $toUser) {
      bookId
      bookTitle
      fromUser
      toUser
      __typename
    }
  }
`;
export const onUpdateOrder = /* GraphQL */ `
  subscription OnUpdateOrder {
    onUpdateOrder {
      orderId
      bookId
      status
      orderDate
      __typename
    }
  }
`;
