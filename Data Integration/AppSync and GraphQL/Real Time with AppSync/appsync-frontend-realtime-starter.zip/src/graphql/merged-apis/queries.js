/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const getBook = /* GraphQL */ `
  query GetBook($id: ID!) {
    getBook(id: $id) {
      id
      title
      authorId
      publisherId
      genres
      publicationYear
      image
      description
      __typename
    }
  }
`;
export const listBooks = /* GraphQL */ `
  query ListBooks(
    $filter: TableBookFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listBooks(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        id
        title
        authorId
        publisherId
        genres
        publicationYear
        image
        description
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const listBooksByGenre = /* GraphQL */ `
  query ListBooksByGenre($genre: String!, $limit: Int, $nextToken: String) {
    listBooksByGenre(genre: $genre, limit: $limit, nextToken: $nextToken) {
      items {
        id
        title
        authorId
        publisherId
        genres
        publicationYear
        image
        description
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const queryBooksByAuthorIndex = /* GraphQL */ `
  query QueryBooksByAuthorIndex($authorId: ID!, $first: Int, $after: String) {
    queryBooksByAuthorIndex(authorId: $authorId, first: $first, after: $after) {
      items {
        id
        title
        authorId
        publisherId
        genres
        publicationYear
        image
        description
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const queryBooksByPublisherIndex = /* GraphQL */ `
  query QueryBooksByPublisherIndex(
    $publisherId: ID!
    $first: Int
    $after: String
  ) {
    queryBooksByPublisherIndex(
      publisherId: $publisherId
      first: $first
      after: $after
    ) {
      items {
        id
        title
        authorId
        publisherId
        genres
        publicationYear
        image
        description
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const getReview = /* GraphQL */ `
  query GetReview($id: ID!) {
    getReview(id: $id) {
      id
      bookId
      userId
      rating
      comment
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const listReviewsByBookId = /* GraphQL */ `
  query ListReviewsByBookId($bookId: ID!, $limit: Int, $nextToken: String) {
    listReviewsByBookId(bookId: $bookId, limit: $limit, nextToken: $nextToken) {
      items {
        id
        bookId
        userId
        rating
        comment
        createdAt
        updatedAt
        __typename
      }
      nextToken
      __typename
    }
  }
`;
export const getAuthor = /* GraphQL */ `
  query GetAuthor($id: ID!) {
    getAuthor(id: $id) {
      id
      name
      numBooks
      hometown
      country
      __typename
    }
  }
`;
export const listAuthors = /* GraphQL */ `
  query ListAuthors($pageSize: Int, $pageNumber: Int) {
    listAuthors(pageSize: $pageSize, pageNumber: $pageNumber) {
      id
      name
      numBooks
      hometown
      country
      __typename
    }
  }
`;
export const none = /* GraphQL */ `
  query None {
    none
  }
`;
export const getUser = /* GraphQL */ `
  query GetUser($username: String!) {
    getUser(username: $username) {
      id
      username
      email
      __typename
    }
  }
`;
export const listUsers = /* GraphQL */ `
  query ListUsers($limit: Int, $nextToken: String) {
    listUsers(limit: $limit, nextToken: $nextToken) {
      items {
        id
        username
        email
        __typename
      }
      nextToken
      __typename
    }
  }
`;
