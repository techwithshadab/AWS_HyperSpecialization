/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const createBook = /* GraphQL */ `
  mutation CreateBook($input: CreateBookInput!) {
    createBook(input: $input) {
      id
      title
      authorId
      publisherId
      genres
      publicationYear
      image
      description
      __typename
    }
  }
`;
export const updateBook = /* GraphQL */ `
  mutation UpdateBook($input: UpdateBookInput!) {
    updateBook(input: $input) {
      id
      title
      authorId
      publisherId
      genres
      publicationYear
      image
      description
      __typename
    }
  }
`;
export const deleteBook = /* GraphQL */ `
  mutation DeleteBook($input: DeleteBookInput!) {
    deleteBook(input: $input) {
      id
      title
      authorId
      publisherId
      genres
      publicationYear
      image
      description
      __typename
    }
  }
`;
export const createReview = /* GraphQL */ `
  mutation CreateReview($input: CreateReviewInput!) {
    createReview(input: $input) {
      id
      bookId
      userId
      rating
      comment
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const updateReview = /* GraphQL */ `
  mutation UpdateReview($input: UpdateReviewInput!) {
    updateReview(input: $input) {
      id
      bookId
      userId
      rating
      comment
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const deleteReview = /* GraphQL */ `
  mutation DeleteReview($input: DeleteReviewInput!) {
    deleteReview(input: $input) {
      id
      bookId
      userId
      rating
      comment
      createdAt
      updatedAt
      __typename
    }
  }
`;
export const createAuthor = /* GraphQL */ `
  mutation CreateAuthor($input: CreateAuthorInput!) {
    createAuthor(input: $input) {
      id
      name
      numBooks
      hometown
      country
      __typename
    }
  }
`;
export const updateAuthor = /* GraphQL */ `
  mutation UpdateAuthor($input: UpdateAuthorInput!) {
    updateAuthor(input: $input) {
      id
      name
      numBooks
      hometown
      country
      __typename
    }
  }
`;
export const deleteAuthor = /* GraphQL */ `
  mutation DeleteAuthor($input: DeleteAuthorInput!) {
    deleteAuthor(input: $input) {
      id
      name
      numBooks
      hometown
      country
      __typename
    }
  }
`;
export const publishBookRecommendation = /* GraphQL */ `
  mutation PublishBookRecommendation($input: BookRecommendationInput!) {
    publishBookRecommendation(input: $input) {
      bookId
      bookTitle
      fromUser
      toUser
      __typename
    }
  }
`;
export const createOrder = /* GraphQL */ `
  mutation CreateOrder($input: OrderInput!) {
    createOrder(input: $input) {
      orderId
      bookId
      status
      orderDate
      __typename
    }
  }
`;
export const updateOrder = /* GraphQL */ `
  mutation UpdateOrder($input: OrderInput!) {
    updateOrder(input: $input) {
      orderId
      bookId
      status
      orderDate
      __typename
    }
  }
`;
