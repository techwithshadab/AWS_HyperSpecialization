import { Amplify } from 'aws-amplify';
import { useState, useRef, useEffect } from 'react';
import { useLocation } from "react-router-dom";
import { FullPageHeader } from './common/full-page-header';
import { ContentLayout, Container, Input, Button, SpaceBetween, ProgressBar } from "@cloudscape-design/components";
import { CustomAppLayout } from './common/common-components';
import { onUpdateOrder } from '../graphql/merged-apis/subscriptions'
import { API } from '@aws-amplify/api';
import awsmobile from "../aws-exports";

function TrackOrder(props) {
    const [orderIdInputVal, setOrderIdInputVal] = useState(props.orderId);
    const [orderId, setOrderId] = useState(props.orderId);
    const [progress, setProgress] = useState("0");
    const [status, setStatus] = useState(null);

    function subscribeOrderStatus() {

    };

    useEffect(() => {

    }, [orderId]);

    return (
        <ContentLayout
            header={
                <FullPageHeader
                    title={"Track your order"}
                    showAlert={props.showAlert}
                    alertStatus={props.alertStatus}
                    handler={props.handler}
                />
            }
        >
            <SpaceBetween direction="vertical" size="m">
                <Container>
                    <hr style={{ "opacity": "0.3" }} />
                    <SpaceBetween direction="vertical" size="s">
                        <Input
                            onChange={({ detail }) =>
                                setOrderIdInputVal(detail.value)
                            }
                            value={orderIdInputVal}
                            placeholder="Enter the order number. Example: cff89e33-94e1-44e2-aa66-8c8cd5894fbc"
                        />
                        <Button variant="primary" onClick={(event) => {
                            event.preventDefault();
                            setOrderId(orderIdInputVal);
                        }}>Ok</Button>
                    </SpaceBetween>
                    <hr style={{ "opacity": "0.3" }} />
                </Container>
                {orderId !== null &&
                    <Container>
                        <hr style={{ "opacity": "0.3" }} />
                        <ProgressBar
                            value={progress}
                            label="Order Status"
                            description={status}
                        />
                        <hr style={{ "opacity": "0.3" }} />
                    </Container>
                }
            </SpaceBetween>
        </ContentLayout>
    );

};

export default function TrackOrderView(props) {
    const appLayout = useRef();
    const location = useLocation();
    console.log(location.state);
    return (
        <CustomAppLayout
            ref={appLayout}
            activeHref={'/track'}
            content={
                <TrackOrder {...props} orderId={location?.state?.orderId ?? null} />
            }
            stickyNotifications={true}
        />
    );
};