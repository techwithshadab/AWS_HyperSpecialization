import { Amplify } from 'aws-amplify';
import { useState, useEffect, useRef } from 'react';
import { API } from '@aws-amplify/api';
import { FullPageHeader } from './common/full-page-header';
import { ContentLayout, Container, TextContent } from "@cloudscape-design/components";
import { CustomAppLayout } from './common/common-components';
import { useAuthenticator } from '@aws-amplify/ui-react';
import { subscribeBookRecommendation } from '../graphql/merged-apis/subscriptions';
import awsmobile from "../aws-exports";

function BookRecommendations(props) {
    const [bookId, setBookID] = useState(null);
    const [recommendations, setRecommendations] = useState([]);
    const { user, _ } = useAuthenticator((context) => [context.user]);
    const username = user ? user.username : '';

    function subscribeRecommendations() {
        Amplify.configure({...awsmobile, API: {
            aws_appsync_graphqlEndpoint: awsmobile.aws_appsync_graphqlEndpoint,
            aws_appsync_authenticationType: 'AMAZON_COGNITO_USER_POOLS'
        }});

        return API.graphql({
            query: subscribeBookRecommendation,
            variables: {
                toUser: username
            }
        }).subscribe({
            next: (response) => {
                const recommendation = response.value.data.subscribeBookRecommendation;
                setBookID(recommendation.bookId);
                recommendations.unshift({
                    id: recommendation.bookId,
                    recommendationFromUser: recommendation,
                });
            }
        });
    };

    useEffect(() => {
        const newRecommendSub = subscribeRecommendations();

        return () => {
            newRecommendSub.unsubscribe();
        };
    }, []);

    return (
        <ContentLayout
            header={
                <FullPageHeader
                    title={"Recommended For You"}
                    showAlert={props.showAlert}
                    alertStatus={props.alertStatus}
                    handler={props.handler}
                />
            }
        >
            <Container>
                <hr style={{ "opacity": "0.3" }} />
                <TextContent>
                    {bookId ?
                        <ul style={{ "list-style": "none" }}>
                            {recommendations.map(message => (
                                <li key={message.id}>{message.recommendationFromUser.bookTitle} <i> by <b>{message.recommendationFromUser.fromUser} </b></i></li>
                            ))}
                        </ul>
                        :
                        <p style={{ "fontSize": "16px" }}> <i>No Recomendations </i></p>
                    }
                </TextContent>
                <hr style={{ "opacity": "0.3" }} />
            </Container>
        </ContentLayout>
    );

};

export default function BookRecommendationsView(props) {
    const appLayout = useRef();
    return (
        <CustomAppLayout
            ref={appLayout}
            activeHref={'/recommendations'}
            content={
                <BookRecommendations {...props} />
            }
            contentType="default"
            stickyNotifications={true}
        />
    );
};