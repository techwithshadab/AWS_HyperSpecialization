import { Amplify } from 'aws-amplify';
import { useState, useEffect, useRef, useReducer } from 'react';
import { useParams, useNavigate } from "react-router-dom";
import { API } from '@aws-amplify/api';
import { useAuthenticator } from "@aws-amplify/ui-react";
import { getBook, listReviewsByBookId} from '../graphql/merged-apis/queries';
import { createReview, createOrder, publishBookRecommendation} from '../graphql/merged-apis/mutations';
import { onCreateReview, onCreateReviewFiltered } from '../graphql/merged-apis/subscriptions';
import { REVIEW_CARD_DEFINITIONS } from '../config/card-config';
import awsmobile from "../aws-exports";

import { CustomAppLayout } from './common/common-components';
import ContentLayout from "@cloudscape-design/components/content-layout";
import ColumnLayout from "@cloudscape-design/components/column-layout";
import Container from "@cloudscape-design/components/container";
import Header from "@cloudscape-design/components/header";
import Box from "@cloudscape-design/components/box";
import Badge from "@cloudscape-design/components/badge";
import Grid from "@cloudscape-design/components/grid";
import Button from "@cloudscape-design/components/button";
import SpaceBetween from "@cloudscape-design/components/space-between";
import Modal from "@cloudscape-design/components/modal";
import Input from "@cloudscape-design/components/input";
import FormField from "@cloudscape-design/components/form-field";
import Textarea from "@cloudscape-design/components/textarea";
import SegmentedControl from "@cloudscape-design/components/segmented-control";
import { Cards } from '@cloudscape-design/components';

function BookDetail(props) {
    const { user } = useAuthenticator((context) => [context.user]);
    const [bookData, setBookData] = useState({genres: []});
    const [username, setUsername] = useState("");
    const [rating, setRating] = useState(0);
    const [reviewComments, setReviewComments] = useState("");
    const [recommendModalVisibility, setRecommendModalVisibility] = useState(false);
    const [reviewModalVisibility, setReviewModalVisibility] = useState(false);
    const [orderModalVisibility, setOrderModalVisibility] = useState(false);
    const [nextToken, setNextToken] = useState(undefined);
    const [bookReviewsData, setBookReviewsData] = useState([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    const reviewChangeReducer = (_, action) => {
        let localReviews = Object.create(bookReviewsData);
        switch (action.type) {
            case 'CREATE':
                setBookReviewsData([action.data, ...localReviews]);
                break;
            default:
                break;
        }
    };
    const [_, dispatch] = useReducer(reviewChangeReducer);

    useEffect(() => {
        Amplify.configure({...awsmobile, API: {
            aws_appsync_graphqlEndpoint : awsmobile.aws_appsync_graphqlEndpoint,
            aws_appsync_apiKey: awsmobile.aws_appsync_apiKey
        }});

        async function getBookDetails(id) {
            const bookData = await API.graphql({
                query: getBook,
                variables: {
                    id: id
                }
            });
            setBookData(bookData.data.getBook);
        };
        
        async function getBookReviews(id) {
            const response = await API.graphql({
                query: listReviewsByBookId,
                variables: {
                    bookId: id,
                    limit: 10,
                    nextToken: nextToken
                }
            });
            if (response.hasOwnProperty("errors")) {
                setBookReviewsData([]);
            } else {
                setBookReviewsData(response.data.listReviewsByBookId.items);
                setNextToken(response.data.listReviewsByBookId.nextToken);
            }
            setLoading(false);
        };

        function subscribeCreateReview() {

        };    

        getBookDetails(props.id);
        getBookReviews(props.id);
        
        // Subscribe to changes

    }, [props.id]);

    const ValueWithLabel = ({ label, children }) => (
        <div>
            <Box variant="awsui-key-label">{label}</Box>
            <div>{children}</div>
        </div>
    );

    async function sendBookRecommendation() {

    };

    async function createBookReview() {

    };

    async function createBookOrder(event) {

    };

    function handleBookRecommendationAction() {
        setRecommendModalVisibility(true);
    };
    
    function handleBookReviewAction() {
        setReviewModalVisibility(true);
    };

    function handleBookOrderAction() {
        setOrderModalVisibility(true);
    };
    
    return (
        <ContentLayout
            header={
                <SpaceBetween size="m">
                    <Header
                        variant="h1"
                        actions={
                            (user !== undefined)
                            ?
                                <SpaceBetween direction="horizontal" size="xs">
                                    <Button variant="primary" onClick={handleBookRecommendationAction}>Recommend</Button>
                                    <Button variant="primary" onClick={handleBookReviewAction}>Review</Button>
                                    <Button variant="primary" onClick={handleBookOrderAction}>Order</Button>
                                </SpaceBetween>
                            : null
                        }
                    >{bookData?.title}</Header>
                </SpaceBetween>
            }
        >
            <SpaceBetween size="m">
                <Container>
                    <Grid gridDefinition={[{colspan: 3}, {colspan: 9}]}>
                        <img src={bookData.image} alt={bookData.img} width="80%" heigh="80%"/>
                        <ValueWithLabel label="Description">
                            <p>{bookData?.description}</p>
                        </ValueWithLabel>
                    </Grid>
                    <ColumnLayout columns={2} variant="text-grid">
                        <SpaceBetween size="l">
                            <ValueWithLabel label="Author ID">{bookData.authorId}</ValueWithLabel>
                            <ValueWithLabel label="Publication Year">{bookData.publicationYear}</ValueWithLabel>
                        </SpaceBetween>
                        <SpaceBetween size="l">
                            <ValueWithLabel label="Publisher ID">{bookData.publisherId}</ValueWithLabel>
                            <ValueWithLabel label="Genres">
                                <SpaceBetween direction="horizontal" size="xs">
                                    {bookData.genres.map(genre => {
                                        return <Badge color="blue" key={`${props.id}-${genre}`}>{genre}</Badge>
                                    })}
                                </SpaceBetween>
                            </ValueWithLabel>
                        </SpaceBetween>
                    </ColumnLayout>
                    <Modal
                    onDismiss={() => setRecommendModalVisibility(false)}
                    visible={recommendModalVisibility}
                    footer={
                        <Box float="right">
                        <SpaceBetween direction="horizontal" size="xs">
                            <Button variant="link" onClick={() => setRecommendModalVisibility(false)}>Cancel</Button>
                            <Button variant="primary" onClick={sendBookRecommendation}>Ok</Button>
                        </SpaceBetween>
                        </Box>
                    }
                    header="Create Recommendation"
                    >
                        <Input
                        onChange={({ detail }) => 
                            setUsername(detail.value)
                        }
                        value={username}
                        placeholder="Enter the username of your friend. Example: admin"
                        />
                    </Modal>
                    <Modal
                    onDismiss={() => setReviewModalVisibility(false)}
                    visible={reviewModalVisibility}
                    footer={
                        <Box float="right">
                        <SpaceBetween direction="horizontal" size="xs">
                            <Button variant="link" onClick={() => setReviewModalVisibility(false)}>Cancel</Button>
                            <Button variant="primary" onClick={createBookReview}>Ok</Button>
                        </SpaceBetween>
                        </Box>
                    }
                    header="Create Review"
                    >
                        <SpaceBetween direction="vertical" size="s">
                            <FormField
                            label="Overall rating"
                            >
                                <SegmentedControl
                                selectedId={rating}
                                onChange={({ detail }) =>
                                    setRating(detail.selectedId)
                                }
                                options={[
                                    { text: "1", id: "1" },
                                    { text: "2", id: "2" },
                                    { text: "3", id: "3" },
                                    { text: "4", id: "4" },
                                    { text: "5", id: "5" }
                                ]}
                                />
                            </FormField>
                            <FormField
                            label="Comments"
                            >
                                <Textarea
                                    onChange={({ detail }) => setReviewComments(detail.value)}
                                    value={reviewComments}
                                    placeholder="Leave a review"
                                />
                            </FormField>
                        </SpaceBetween>
                    </Modal>
                    <Modal
                      onDismiss={() => setOrderModalVisibility(false)}
                      visible={orderModalVisibility}
                      footer={
                        <Box float="right">
                          <SpaceBetween direction="horizontal" size="xs">
                            <Button variant="link" onClick={() => setOrderModalVisibility(false)}>No</Button>
                            <Button variant="primary" onClick={(e) => createBookOrder(e)}>Yes</Button>
                          </SpaceBetween>
                        </Box>
                      }
                      header="Confirm Order"
                    >
                        Do you want to proceed?
                    </Modal>
                </Container>
                <Container
                    header={
                        <Header
                        variant="h2"
                        >
                        Top Reviews
                        </Header>
                    }
                    >
                    <Cards 
                        stickyHeader={true}
                        cardDefinition={REVIEW_CARD_DEFINITIONS()}
                        cardsPerRow={[
                            { cards: 1 },
                            { minWidth: 100, cards: 1 }
                        ]}
                        loading={loading}
                        loadingText="Loading Reviews"
                        items={bookReviewsData}
                    />
                </Container>
            </SpaceBetween>
        </ContentLayout>
    );
}

export default function BookDetailView(props) {
    const appLayout = useRef();
    const { id } = useParams();

    return (
        <CustomAppLayout
            ref={appLayout}
            activeHref={`/books/${id}`}
            content={
                <BookDetail id={id} {...props} />
            }
            stickyNotifications={true}
        />
    );
};