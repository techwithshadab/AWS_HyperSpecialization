// 1. Import environment variables and dependencies
const { 
    RDS_REGION, PROXY_ENDPOINT,
    DB_NAME, DB_USERNAME,
    SEED_DATA_BUCKET_NAME, SEED_DATA_OBJECT_KEY
} = process.env;
const mysql = require('mysql2/promise');
const csv = require('csv-string');

const { S3Client, GetObjectCommand } = require("@aws-sdk/client-s3");
const { Signer } = require("@aws-sdk/rds-signer");

// 2. Instantiate clients
const s3Client = new S3Client({ region: RDS_REGION });
let connection;

// 3. Define the handler function
exports.handler = async () => {
    const conn = await getConnection();

    const getObjectCommand = new GetObjectCommand({
        Bucket: SEED_DATA_BUCKET_NAME,
        Key: SEED_DATA_OBJECT_KEY,
    });
    try {
        await createAuthorsTable(conn);
        const getS3ObjectResponse = await s3Client.send(getObjectCommand);
        const str = await getS3ObjectResponse.Body.transformToString();
        return await generateAuthors(conn, csv.parse(str));
    }
    catch (err) {
        console.log(err);
    }
}

async function getConnection() {
    if (connection && connection.threadId) {
        return connection;
    }
    
    const signer = new Signer({
        region: RDS_REGION,
        hostname: PROXY_ENDPOINT,
        port: 3306,
        username: DB_USERNAME
    });
    
    let token = await signer.getAuthToken({ username: DB_USERNAME });
    
    let connectionConfig = {
        host: PROXY_ENDPOINT,
        user: DB_USERNAME,
        database: DB_NAME,
        password: token,
        ssl: { rejectUnauthorized: false },
        authPlugins: { mysql_clear_password: () => () => signer.getAuthToken() }
    };
    
    connection = await mysql.createConnection(connectionConfig);
    console.log(connection.threadId);
    return connection;
}


async function createAuthorsTable(conn) {
    try {
        await conn.execute("CREATE TABLE authors ( id VARCHAR(255), name VARCHAR(255), numBooks INT, hometown VARCHAR(255), country VARCHAR(255), PRIMARY KEY(`id`))");
    } catch (err) {
        throw err;
    }
}

async function generateAuthors(conn, authors) {
    console.log("Seeding authors: ", authors.length);
    for (let i = 1; i < authors.length; i += 1) {
        let author = authors[i];
        const [id, name, numBooks, hometown, country] = author;
        await conn.execute("INSERT INTO authors (id,name,numBooks,hometown,country) VALUES(?, ?, ?, ?, ?)", [id, name, numBooks, hometown, country]);
    }
}
