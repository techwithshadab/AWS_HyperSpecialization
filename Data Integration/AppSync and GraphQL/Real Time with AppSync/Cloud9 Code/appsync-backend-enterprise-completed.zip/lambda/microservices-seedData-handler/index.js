// 1. Import environment variables and dependencies
const { REVIEWS_TABLE_NAME, REGION, SEED_DATA_BUCKET_NAME, SEED_DATA_OBJECT_KEY } = process.env
const { S3Client, GetObjectCommand } = require("@aws-sdk/client-s3");
const { DynamoDBDocumentClient, BatchWriteCommand } = require("@aws-sdk/lib-dynamodb");
const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");

// 2. Instantiate clients
const client = DynamoDBDocumentClient.from(new DynamoDBClient({ region: REGION }));
const s3Client = new S3Client({ region: REGION });

// 3. Define the handler function
exports.handler = async () => {
    const getObjectCommand = new GetObjectCommand({
        Bucket: SEED_DATA_BUCKET_NAME,
        Key: SEED_DATA_OBJECT_KEY,
    });
    try {
        const getS3ObjectResponse = await s3Client.send(getObjectCommand);
        const str = await getS3ObjectResponse.Body.transformToString();
        return await putReviews(JSON.parse(str));
    }
    catch (err) {
        console.log(err);
    }
}

// 4. Helper function to batch write reviews
async function putReviews(reviews) {
    console.log("Seeding reviews:", reviews.length);
    for (let i = 0; i < reviews.length; i += 25) {
        const batch = reviews.slice(i, i + 25);
        const params = {
            RequestItems: {
                [REVIEWS_TABLE_NAME]: batch.map((review) => ({
                    PutRequest: {
                        Item: review,
                    }
                }))
            }
        }
        await client.send(new BatchWriteCommand(params));
    }
    return "Reviews seeded successfully";
}