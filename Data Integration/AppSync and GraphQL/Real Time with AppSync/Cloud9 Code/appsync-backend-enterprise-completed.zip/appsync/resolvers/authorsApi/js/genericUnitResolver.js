import { util } from '@aws-appsync/utils'

export function request(ctx) {
    if (ctx.arguments.input) {
        ctx.arguments.input.id = ctx.arguments.input.id ?? util.autoId();
    }
    return {
        operation: 'Invoke',
        payload: ctx
    };
}

export function response(ctx) {
    const { error, data } = ctx.result;
    if (error) {
        util.error(error.message, error.name, null);
    }
    return data;
}
