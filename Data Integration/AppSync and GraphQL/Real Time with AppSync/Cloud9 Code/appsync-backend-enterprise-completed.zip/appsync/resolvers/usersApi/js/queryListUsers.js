import { util } from '@aws-appsync/utils';

export function request(ctx) {
    const { limit = 20, nextToken = null } = ctx.args;
    return {
        "version": "2018-05-29",
        "method": "GET",
        "params": {
            "query": {
                "limit": limit,
                "nextToken": nextToken !== null ? util.urlEncode(nextToken) : nextToken
            },
            "headers": {
                "Content-Type": "application/json"
            }
        },
        "resourcePath": `/prod/users`
    };
}

export function response(ctx) {
    if (ctx.result.statusCode === 200) {
        const { items = [], nextToken } = JSON.parse(ctx.result.body);
        return { items, nextToken };
    } else {
        const result = JSON.parse(ctx.result.body);
        return util.appendError(result.error);
    }
}
