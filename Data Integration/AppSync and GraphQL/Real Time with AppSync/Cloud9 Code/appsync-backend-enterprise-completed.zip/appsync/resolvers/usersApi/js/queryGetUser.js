import { util } from '@aws-appsync/utils';

export function request(ctx) {
    return {
        "version": "2018-05-29",
        "method": "GET",
        "params": {
            "query": ctx.args,
            "headers": {
                "Content-Type": "application/json"
            }
        },
        "resourcePath": `/prod/users/${ctx.args.username}`
    };
}

export function response(ctx) {
    if (ctx.result.statusCode === 200) {
        return JSON.parse(ctx.result.body);
    } else {
        const result = JSON.parse(ctx.result.body);
        return util.appendError(result.error);
    }
}
