import os
import csv
import json
import boto3
import requests
import argparse
from datetime import datetime
from aws_requests_auth.boto_utils import BotoAWSRequestsAuth

GQL_URL = os.environ["graphqlEndpoint"]
REGION = os.environ["awsRegion"]
REPORT_BUCKET = os.environ['reportBucket']

LIST_INVENTORY = """
    query($limit: Int, $nextToken: String){
        listInventory(limit: $limit, nextToken: $nextToken) {
            items {
                id
                inventory
            }
            nextToken
        }
    }
"""

CREATE_INVENTORY = """
    mutation($input: InventoryInput!){
        createInventory(input: $input) {
            id
        }
    }
"""

HOST=GQL_URL.replace('https://', '').replace('/graphql', '')
AUTH=BotoAWSRequestsAuth(
    aws_host=HOST,
    aws_region=REGION,
    aws_service='appsync'
)

def list_inventory(nextToken=None):
    variables = {"limit": 200, "nextToken": nextToken}
    response = requests.post(url=GQL_URL, json={"query": LIST_INVENTORY, "variables": json.dumps(variables)}, auth=AUTH)
    if response.status_code == 200:
        return json.loads(response.text)
    else:
        return response.status_code
        
def generate_inventory_report():
    response = list_inventory()
    items = response['data']['listInventory']['items']
    nextToken = response['data']['listInventory']['nextToken']
    
    while nextToken != None:
        response = list_inventory(nextToken=nextToken)
        nextToken = response['data']['listInventory']['nextToken']
        items.extend(response['data']['listInventory']['items'])
    
    if len(items) > 0:
        dt = datetime.now()
        dt_stamp = dt.strftime("%Y-%m-%d_%H:%M:%S")
        filename = f"report-{dt_stamp}.csv"
        with open(filename, "w", newline="") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=["bookId", "inventory"])
            writer.writeheader()
            for item in items:
                writer.writerow({"bookId": item["id"], "inventory": item["inventory"]})
            
            csvfile.close()
        
        s3_client = boto3.client('s3')
        response = s3_client.upload_file(filename, REPORT_BUCKET, f"reports/{filename}")
        print(response)
        

def generate_inventory():
    success = 0
    error = 0
    with open('inventory.json', 'r') as inventory_file:
        inventory = json.load(inventory_file)
        for item in inventory['inventory']:
            variables = {"input": {"id": item['id'], "inventory": item['inventory']}}
            response = requests.post(url=GQL_URL, json={"query": CREATE_INVENTORY, "variables": json.dumps(variables)}, auth=AUTH)
            print(json.loads(response.text))
            if response.status_code == 200:
                success += 1
            else:
                error += 1
    
        inventory_file.close()
    return success, error

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Inventory management system")
    parser.add_argument('--command', action='store', dest='command', choices=['report', 'create'], required=True)
    args = parser.parse_args()
    
    if args.command == 'report':
        generate_inventory_report()
    elif args.command == 'create':
        success, error = generate_inventory()
        print(f"Success: {success}\nError: {error}")
