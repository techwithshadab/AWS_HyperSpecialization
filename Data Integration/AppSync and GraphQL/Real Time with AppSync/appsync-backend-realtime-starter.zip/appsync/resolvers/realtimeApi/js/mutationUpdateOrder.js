export function request(ctx) {
    const { input: values } = ctx.arguments;
    return { payload : values};
}

export function response(ctx) {
    return ctx.result;
}